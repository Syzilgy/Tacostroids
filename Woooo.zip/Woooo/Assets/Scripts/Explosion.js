﻿#pragma strict

function Start () {
	Invoke("KillMe", 0.3);
}

function KillMe () {
Destroy(gameObject);
}